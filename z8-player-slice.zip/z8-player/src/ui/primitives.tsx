import React, { useState } from 'react';
import { ActivityIndicator, Pressable, Text as RNText, TextInput, View, type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { radius, space, type } from '../theme/tokens';

type TextVariant = keyof typeof type;
export function Text({ v = 'base', muted, color, style, children, ...rest }: {
  v?: TextVariant; muted?: boolean; color?: string; style?: StyleProp<TextStyle>; children?: React.ReactNode; numberOfLines?: number; accessibilityRole?: 'header' | 'text';
}) {
  const { colors } = useTheme();
  const t = type[v];
  return (
    <RNText {...rest} style={[{ fontSize: t.size, lineHeight: t.line, fontWeight: String(t.weight) as TextStyle['fontWeight'], color: color ?? (muted ? colors.textMuted : colors.text) }, style]}>
      {children}
    </RNText>
  );
}

/** Focus ring state shared by every pressable: a 3px accent ring, visible with keyboard or D-pad. */
export function useFocus() {
  const [focused, setFocused] = useState(false);
  return { focused, onFocus: () => setFocused(true), onBlur: () => setFocused(false) };
}

export function Button({ title, onPress, variant = 'primary', size = 'md', loading, disabled, style, accessibilityLabel }: {
  title: string; onPress: () => void; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'md' | 'lg';
  loading?: boolean; disabled?: boolean; style?: StyleProp<ViewStyle>; accessibilityLabel?: string;
}) {
  const { colors } = useTheme();
  const f = useFocus();
  const bg = variant === 'primary' ? colors.accent : variant === 'secondary' ? colors.surface : 'transparent';
  const fg = variant === 'primary' ? colors.onAccent : variant === 'ghost' ? colors.accent : variant === 'danger' ? colors.danger : colors.text;
  const off = disabled || loading;
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} accessibilityState={{ disabled: !!off, busy: !!loading }}
      disabled={off} onPress={onPress} onFocus={f.onFocus} onBlur={f.onBlur}
      style={({ pressed }) => [{
        minHeight: size === 'lg' ? 56 : 44, paddingHorizontal: space[4], borderRadius: radius.md, backgroundColor: bg,
        borderWidth: f.focused ? 3 : 1, borderColor: f.focused ? colors.accent : variant === 'secondary' ? colors.border : 'transparent',
        alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: space[2],
        opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
      }, style]}
    >
      {loading ? <ActivityIndicator color={fg} /> : null}
      <Text v="base" color={fg} style={{ fontWeight: '600' }}>{title}</Text>
    </Pressable>
  );
}

export function Field({ label, value, onChangeText, error, secure, keyboard = 'default', placeholder, autoFocus, multiline }: {
  label: string; value: string; onChangeText: (t: string) => void; error?: string; secure?: boolean;
  keyboard?: 'default' | 'url' | 'email-address'; placeholder?: string; autoFocus?: boolean; multiline?: boolean;
}) {
  const { colors } = useTheme();
  const f = useFocus();
  const [shown, setShown] = useState(false);
  return (
    <View style={{ gap: space[1] }}>
      <Text v="sm" style={{ fontWeight: '600' }}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TextInput
          accessibilityLabel={label} value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={colors.textMuted}
          secureTextEntry={!!secure && !shown} keyboardType={keyboard} autoCapitalize="none" autoCorrect={false} autoFocus={autoFocus}
          onFocus={f.onFocus} onBlur={f.onBlur} multiline={multiline}
          style={{
            flex: 1, minHeight: 48, paddingHorizontal: space[3], borderRadius: radius.md, color: colors.text, backgroundColor: colors.bg,
            fontSize: 16, borderWidth: f.focused ? 3 : 1, borderColor: error ? colors.danger : f.focused ? colors.accent : colors.borderInput,
          }}
        />
        {secure ? (
          <Pressable accessibilityRole="button" accessibilityLabel={shown ? 'Hide password' : 'Show password'} onPress={() => setShown(!shown)} style={{ minWidth: 44, minHeight: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Text v="sm" color={colors.accent} style={{ fontWeight: '600' }}>{shown ? 'Hide' : 'Show'}</Text>
          </Pressable>
        ) : null}
      </View>
      {error ? <Text v="sm" color={colors.danger} accessibilityRole="text">{error}</Text> : null}
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  return <View style={[{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radius.lg, padding: space[4] }, style]}>{children}</View>;
}

export function ProgressBar({ fraction }: { fraction: number }) {
  const { colors } = useTheme();
  const pct = Math.round(Math.max(0, Math.min(1, fraction)) * 100);
  return (
    <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: pct }} style={{ height: 4, borderRadius: 4, backgroundColor: colors.border, overflow: 'hidden' }}>
      <View style={{ height: 4, width: `${pct}%`, backgroundColor: colors.accent }} />
    </View>
  );
}

/** Same layout for every empty, loading and error state: icon tile, title, one sentence, optional button. */
export function StateMessage({ title, body, action, onAction, tone = 'normal' }: { title: string; body?: string; action?: string; onAction?: () => void; tone?: 'normal' | 'error' }) {
  const { colors } = useTheme();
  return (
    <View accessibilityLiveRegion="polite" style={{ alignItems: 'center', gap: space[3], padding: space[6] }}>
      <View style={{ width: 48, height: 48, borderRadius: radius.lg, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' }}>
        <Text v="lg" color={tone === 'error' ? colors.danger : colors.accent}>{tone === 'error' ? '!' : 'Z8'}</Text>
      </View>
      <Text v="lg" style={{ textAlign: 'center' }} accessibilityRole="header">{title}</Text>
      {body ? <Text v="sm" muted style={{ textAlign: 'center', maxWidth: 360 }}>{body}</Text> : null}
      {action && onAction ? <Button title={action} onPress={onAction} /> : null}
    </View>
  );
}

export function Skeleton({ height = 64 }: { height?: number }) {
  const { colors } = useTheme();
  return <View style={{ height, borderRadius: radius.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }} />;
}

export function Header({ title, onBack, right }: { title: string; onBack?: () => void; right?: React.ReactNode }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: space[2], paddingHorizontal: space[4], paddingVertical: space[3], minHeight: 56 }}>
      {onBack ? <Button title="Back" variant="ghost" onPress={onBack} accessibilityLabel="Go back" /> : null}
      <Text v="lg" style={{ flex: 1 }} numberOfLines={1} accessibilityRole="header">{title}</Text>
      {right}
    </View>
  );
}
