import React, { createContext, useContext, useMemo } from 'react';
import { MemoryRepo, MemorySecretStore, type Repo, type SecretStore } from '../logic/repo';
import type { FetchLike } from '../logic/xtream';

export interface AppServices { repo: Repo; secrets: SecretStore; fetchFn: FetchLike }
const Ctx = createContext<AppServices | null>(null);

export function AppProvider({ children, services }: { children: React.ReactNode; services?: Partial<AppServices> }) {
  const value = useMemo<AppServices>(() => ({
    repo: services?.repo ?? new MemoryRepo(),
    secrets: services?.secrets ?? new MemorySecretStore(),
    // Real network by default. The demo playlist swaps this out for a built-in fake.
    fetchFn: services?.fetchFn ?? ((url) => fetch(url) as unknown as ReturnType<FetchLike>),
  }), [services]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useApp(): AppServices {
  const v = useContext(Ctx);
  if (!v) throw new Error('AppProvider missing');
  return v;
}
