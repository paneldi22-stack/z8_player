import { Platform } from 'react-native';
import type { FetchLike } from '../logic/xtream';

/**
 * Built-in demo playlist for development and screenshots. It makes no network
 * call: the playlist text is served from memory and the streams are either the
 * bundled test clip (web) or a public test stream (phone).
 */
export const DEMO_URL = 'https://demo.z8.invalid/playlist.m3u';

function clip(): string {
  if (Platform.OS === 'web' && typeof window !== 'undefined') return `${window.location.origin}/test.webm`;
  return 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
}

export function demoPlaylistText(): string {
  const c = clip();
  return [
    '#EXTM3U',
    `#EXTINF:-1 tvg-id="demo.test" group-title="Test clips",Test pattern`, c,
    `#EXTINF:-1 tvg-id="demo.test2" group-title="Test clips",Test pattern two`, c,
    `#EXTINF:-1 tvg-id="demo.broken" group-title="Broken on purpose",Stream that fails`, 'http://127.0.0.1:1/nope.ts',
    `#EXTINF:-1 tvg-id="demo.long" group-title="Broken on purpose",A channel with a really long name that should be cut off with an ellipsis instead of breaking the row layout`, c,
  ].join('\n');
}

export const demoFetch: FetchLike = async (url) => {
  if (url === DEMO_URL) return { ok: true, status: 200, text: async () => demoPlaylistText() };
  return { ok: false, status: 404, text: async () => '' };
};
