export type PlaylistType = 'xtream' | 'm3u';
export type CategoryKind = 'live' | 'movie' | 'series';

export interface Playlist {
  id: string;
  displayName: string;
  type: PlaylistType;
  serverUrl?: string;
  username?: string;
  secretRef?: string; // key in the secure store, never the password itself
  m3uUrl?: string;
  lastSyncAt?: number;
}

export interface Category {
  id: string;
  playlistId: string;
  kind: CategoryKind;
  remoteId: string;
  name: string;
  hidden: boolean;
  locked: boolean;
  sort: number;
}

export interface Channel {
  id: string;
  playlistId: string;
  categoryId: string | null;
  remoteId: string;
  name: string;
  logoUrl?: string;
  streamRef: string; // xtream: stream id. m3u: the stream URL.
  epgChannelId?: string;
}

export interface NewPlaylist {
  displayName: string;
  type: PlaylistType;
  serverUrl?: string;
  username?: string;
  password?: string;
  m3uUrl?: string;
}

export type SyncStep = 'login' | 'categories' | 'channels' | 'saving' | 'done';
export interface SyncProgress { step: SyncStep; fraction: number }
export interface SyncResult { categories: number; channels: number }

export type Z8ErrorCode =
  | 'invalid_url'
  | 'auth_failed'
  | 'account_expired'
  | 'network'
  | 'bad_response'
  | 'empty';

export class Z8Error extends Error {
  constructor(public code: Z8ErrorCode, message: string) {
    super(message);
    this.name = 'Z8Error';
  }
}
