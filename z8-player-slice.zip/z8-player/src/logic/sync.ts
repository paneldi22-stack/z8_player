import { parseM3u } from './m3u';
import { Z8Error } from './types';
import type { Playlist, SyncProgress, SyncResult } from './types';
import type { Repo, SecretStore } from './repo';
import { xtreamLiveCategories, xtreamLiveStreams, xtreamLiveUrl, xtreamLogin } from './xtream';
import type { FetchLike } from './xtream';

type Progress = (p: SyncProgress) => void;

/** One sync per playlist at a time. A second call while one runs returns the same promise. */
const running = new Map<string, Promise<SyncResult>>();

export function syncPlaylist(
  playlist: Playlist, repo: Repo, secrets: SecretStore, fetchFn: FetchLike, onProgress: Progress = () => {},
): Promise<SyncResult> {
  const existing = running.get(playlist.id);
  if (existing) return existing;
  const job = doSync(playlist, repo, secrets, fetchFn, onProgress).finally(() => running.delete(playlist.id));
  running.set(playlist.id, job);
  return job;
}

async function doSync(playlist: Playlist, repo: Repo, secrets: SecretStore, fetchFn: FetchLike, onProgress: Progress): Promise<SyncResult> {
  if (playlist.type === 'xtream') {
    const password = playlist.secretRef ? await secrets.get(playlist.secretRef) : undefined;
    if (!playlist.serverUrl || !playlist.username || !password) throw new Z8Error('auth_failed', 'This playlist is missing its sign-in details.');
    const creds = { serverUrl: playlist.serverUrl, username: playlist.username, password };
    onProgress({ step: 'login', fraction: 0.1 });
    await xtreamLogin(fetchFn, creds);
    onProgress({ step: 'categories', fraction: 0.3 });
    const cats = await xtreamLiveCategories(fetchFn, creds);
    onProgress({ step: 'channels', fraction: 0.5 });
    const streams = await xtreamLiveStreams(fetchFn, creds);
    if (streams.length === 0) throw new Z8Error('empty', 'This playlist has no channels.');
    onProgress({ step: 'saving', fraction: 0.85 });
    await repo.replaceContent(
      playlist.id,
      cats.map((c, i) => ({ playlistId: playlist.id, kind: 'live' as const, remoteId: String(c.category_id), name: c.category_name, hidden: false, locked: false, sort: i })),
      streams.map((s) => ({
        remoteId: String(s.stream_id), name: s.name, logoUrl: s.stream_icon || undefined,
        streamRef: String(s.stream_id), epgChannelId: s.epg_channel_id || undefined,
        categoryRemoteId: s.category_id != null ? String(s.category_id) : null,
      })),
    );
    onProgress({ step: 'done', fraction: 1 });
    return { categories: cats.length, channels: streams.length };
  }

  if (!playlist.m3uUrl) throw new Z8Error('invalid_url', 'Paste the playlist link.');
  onProgress({ step: 'channels', fraction: 0.3 });
  let text: string;
  try {
    const res = await fetchFn(playlist.m3uUrl);
    if (res.status === 401 || res.status === 403) throw new Z8Error('auth_failed', 'The provider refused the link. It may have expired.');
    if (!res.ok) throw new Z8Error('bad_response', `The server answered with an error (${res.status}).`);
    text = await res.text();
  } catch (e) {
    if (e instanceof Z8Error) throw e;
    throw new Z8Error('network', "Couldn't reach the server. Check the link and your connection.");
  }
  const entries = parseM3u(text);
  if (entries.length === 0) throw new Z8Error('empty', 'This playlist has no channels.');
  onProgress({ step: 'saving', fraction: 0.85 });
  const groups = [...new Set(entries.map((e) => e.group ?? 'Other'))];
  await repo.replaceContent(
    playlist.id,
    groups.map((g, i) => ({ playlistId: playlist.id, kind: 'live' as const, remoteId: g, name: g, hidden: false, locked: false, sort: i })),
    entries.map((e, i) => ({
      remoteId: e.tvgId ? `${e.tvgId}` : `${i}:${e.url}`, name: e.name, logoUrl: e.logo, streamRef: e.url,
      epgChannelId: e.tvgId, categoryRemoteId: e.group ?? 'Other',
    })),
  );
  onProgress({ step: 'done', fraction: 1 });
  return { categories: groups.length, channels: entries.length };
}

/** Turn a stored channel into a playable URL. Credentials are read only here, at play time. */
export async function resolveStreamUrl(playlist: Playlist, streamRef: string, secrets: SecretStore): Promise<string> {
  if (playlist.type === 'm3u') return streamRef;
  const password = playlist.secretRef ? await secrets.get(playlist.secretRef) : undefined;
  if (!playlist.serverUrl || !playlist.username || !password) throw new Z8Error('auth_failed', 'This playlist is missing its sign-in details.');
  return xtreamLiveUrl({ serverUrl: playlist.serverUrl, username: playlist.username, password }, streamRef);
}
