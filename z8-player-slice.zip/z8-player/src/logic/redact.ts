/** Remove credentials from any text before it reaches a log, a toast or a crash report. */
export function redact(text: string, secrets: Array<string | undefined> = []): string {
  let out = text
    .replace(/([?&](?:username|user|password|pass|pwd|token)=)[^&\s]*/gi, '$1***')
    .replace(/(\/(?:live|movie|series)\/)[^/\s]+\/[^/\s]+\//gi, '$1***/***/');
  for (const s of secrets) {
    if (s && s.length >= 3) out = out.split(s).join('***');
  }
  return out;
}
