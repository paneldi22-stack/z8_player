import type { Category, CategoryKind, Channel, NewPlaylist, Playlist } from './types';

/** A channel as it arrives from a sync, before it has an id or a resolved category. */
export type ChannelInput = Omit<Channel, 'id' | 'categoryId' | 'playlistId'> & { categoryRemoteId: string | null };

/** Where passwords live. Native: the OS keystore. Tests and web demo: memory. */
export interface SecretStore {
  get(ref: string): Promise<string | undefined>;
  set(ref: string, value: string): Promise<void>;
  remove(ref: string): Promise<void>;
}

/**
 * The data layer. Screens only talk to this. The in-memory version below is
 * the fake one used for the slice; the SQLite version (schema.sql) must keep
 * these exact signatures so swapping it changes no screen code.
 */
export interface Repo {
  listPlaylists(): Promise<Playlist[]>;
  getPlaylist(id: string): Promise<Playlist | undefined>;
  addPlaylist(input: NewPlaylist, secrets: SecretStore): Promise<Playlist>;
  deletePlaylist(id: string, secrets: SecretStore): Promise<void>;
  replaceContent(playlistId: string, cats: Omit<Category, 'id'>[], chans: ChannelInput[]): Promise<void>;
  listCategories(playlistId: string, kind: CategoryKind): Promise<Category[]>;
  listChannels(playlistId: string, categoryId: string | null): Promise<Channel[]>;
  counts(playlistId: string): Promise<{ channels: number; categories: number }>;
}

export class MemorySecretStore implements SecretStore {
  private m = new Map<string, string>();
  async get(ref: string) { return this.m.get(ref); }
  async set(ref: string, value: string) { this.m.set(ref, value); }
  async remove(ref: string) { this.m.delete(ref); }
}

let counter = 0;
export const newId = (): string =>
  (globalThis.crypto && 'randomUUID' in globalThis.crypto)
    ? globalThis.crypto.randomUUID()
    : `id-${Date.now().toString(36)}-${(counter++).toString(36)}`;

export class MemoryRepo implements Repo {
  private playlists = new Map<string, Playlist>();
  private cats = new Map<string, Category[]>();
  private chans = new Map<string, Channel[]>();

  async listPlaylists() { return [...this.playlists.values()]; }
  async getPlaylist(id: string) { return this.playlists.get(id); }

  async addPlaylist(input: NewPlaylist, secrets: SecretStore): Promise<Playlist> {
    const id = newId();
    const p: Playlist = {
      id, displayName: input.displayName.trim() || 'My playlist', type: input.type,
      serverUrl: input.serverUrl, username: input.username, m3uUrl: input.m3uUrl,
    };
    if (input.type === 'xtream' && input.password) {
      p.secretRef = `playlist:${id}:password`;
      await secrets.set(p.secretRef, input.password);
    }
    this.playlists.set(id, p);
    return p;
  }

  async deletePlaylist(id: string, secrets: SecretStore) {
    const p = this.playlists.get(id);
    if (p?.secretRef) await secrets.remove(p.secretRef);
    this.playlists.delete(id); this.cats.delete(id); this.chans.delete(id);
  }

  async replaceContent(
    playlistId: string,
    cats: Omit<Category, 'id'>[],
    chans: ChannelInput[],
  ) {
    // Upsert by remoteId so ids (and later favorites and resume positions) survive a re-sync.
    const oldCats = this.cats.get(playlistId) ?? [];
    const byRemote = new Map(oldCats.map((c) => [`${c.kind}:${c.remoteId}`, c]));
    const nextCats: Category[] = cats.map((c) => {
      const prev = byRemote.get(`${c.kind}:${c.remoteId}`);
      return { ...c, id: prev?.id ?? newId(), hidden: prev?.hidden ?? c.hidden, locked: prev?.locked ?? c.locked };
    });
    const catByRemote = new Map(nextCats.map((c) => [c.remoteId, c.id]));
    const oldChans = new Map((this.chans.get(playlistId) ?? []).map((c) => [c.remoteId, c]));
    const nextChans: Channel[] = chans.map((c) => ({
      id: oldChans.get(c.remoteId)?.id ?? newId(),
      playlistId,
      categoryId: c.categoryRemoteId != null ? catByRemote.get(c.categoryRemoteId) ?? null : null,
      remoteId: c.remoteId, name: c.name, logoUrl: c.logoUrl, streamRef: c.streamRef, epgChannelId: c.epgChannelId,
    }));
    this.cats.set(playlistId, nextCats);
    this.chans.set(playlistId, nextChans);
    const p = this.playlists.get(playlistId);
    if (p) this.playlists.set(playlistId, { ...p, lastSyncAt: Math.floor(Date.now() / 1000) });
  }

  async listCategories(playlistId: string, kind: CategoryKind) {
    return (this.cats.get(playlistId) ?? []).filter((c) => c.kind === kind && !c.hidden).sort((a, b) => a.sort - b.sort);
  }

  async listChannels(playlistId: string, categoryId: string | null) {
    const all = this.chans.get(playlistId) ?? [];
    return categoryId ? all.filter((c) => c.categoryId === categoryId) : all;
  }

  async counts(playlistId: string) {
    return { channels: (this.chans.get(playlistId) ?? []).length, categories: (this.cats.get(playlistId) ?? []).length };
  }
}
