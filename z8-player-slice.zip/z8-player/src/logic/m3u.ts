export interface M3uEntry {
  name: string;
  url: string;
  logo?: string;
  group?: string;
  tvgId?: string;
}

const ATTR = /([A-Za-z0-9_-]+)="([^"]*)"/g;

/**
 * Parse an M3U or M3U8 playlist. Line by line, so a very large file is never
 * split into one giant array of lines. Unknown tags are ignored.
 */
export function parseM3u(text: string): M3uEntry[] {
  const entries: M3uEntry[] = [];
  let pending: Omit<M3uEntry, 'url'> | null = null;
  let extGroup: string | undefined;
  let start = 0;
  const len = text.length;

  while (start <= len) {
    let end = text.indexOf('\n', start);
    if (end === -1) end = len;
    const line = text.slice(start, end).trim();
    start = end + 1;
    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      const comma = findNameComma(line);
      const head = comma === -1 ? line : line.slice(0, comma);
      const name = comma === -1 ? '' : line.slice(comma + 1).trim();
      const attrs: Record<string, string> = {};
      for (const m of head.matchAll(ATTR)) attrs[m[1]!.toLowerCase()] = m[2]!;
      pending = {
        name: name || attrs['tvg-name'] || 'Untitled',
        logo: attrs['tvg-logo'] || undefined,
        group: attrs['group-title'] || extGroup || undefined,
        tvgId: attrs['tvg-id'] || undefined,
      };
    } else if (line.startsWith('#EXTGRP:')) {
      // Usually comes right after #EXTINF (for that entry), sometimes before it.
      extGroup = line.slice(8).trim() || undefined;
      if (pending && !pending.group) pending.group = extGroup;
    } else if (line.startsWith('#')) {
      continue;
    } else if (pending) {
      entries.push({ ...pending, url: line });
      pending = null;
      extGroup = undefined;
    }
  }
  return entries;
}

/** The comma that separates attributes from the display name, ignoring commas inside quotes. */
function findNameComma(line: string): number {
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') inQuotes = !inQuotes;
    else if (c === ',' && !inQuotes) return i;
  }
  return -1;
}
