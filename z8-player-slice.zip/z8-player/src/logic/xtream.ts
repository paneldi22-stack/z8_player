import { Z8Error } from './types';
import { redact } from './redact';

export type FetchLike = (url: string) => Promise<{ ok: boolean; status: number; text(): Promise<string> }>;

export interface XtreamCreds { serverUrl: string; username: string; password: string }
export interface XtreamCategory { category_id: string; category_name: string }
export interface XtreamStream {
  stream_id: number | string;
  name: string;
  stream_icon?: string;
  category_id?: string | null;
  epg_channel_id?: string | null;
  tv_archive?: number | string;
}

/** Add a scheme if missing, strip trailing slashes and any player_api.php tail. */
export function normalizeServerUrl(raw: string): string {
  let s = raw.trim();
  if (!s) throw new Z8Error('invalid_url', 'Enter the server address.');
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  let u: URL;
  try { u = new URL(s); } catch { throw new Z8Error('invalid_url', "That server address doesn't look right."); }
  const path = u.pathname.replace(/\/(player_api|get)\.php$/i, '').replace(/\/+$/, '');
  return `${u.protocol}//${u.host}${path}`;
}

function apiUrl(c: XtreamCreds, action?: string): string {
  const q = new URLSearchParams({ username: c.username, password: c.password });
  if (action) q.set('action', action);
  return `${normalizeServerUrl(c.serverUrl)}/player_api.php?${q.toString()}`;
}

async function getJson(fetchFn: FetchLike, c: XtreamCreds, action?: string): Promise<unknown> {
  let res;
  try {
    res = await fetchFn(apiUrl(c, action));
  } catch (e) {
    throw new Z8Error('network', redact("Couldn't reach the server. Check the address and your connection.", [c.password]));
  }
  if (res.status === 401 || res.status === 403) throw new Z8Error('auth_failed', 'Wrong username or password.');
  if (!res.ok) throw new Z8Error('bad_response', `The server answered with an error (${res.status}).`);
  const body = await res.text();
  try { return JSON.parse(body); } catch { throw new Z8Error('bad_response', "The server's answer wasn't what we expected."); }
}

export async function xtreamLogin(fetchFn: FetchLike, c: XtreamCreds): Promise<{ expiresAt?: number }> {
  const data = (await getJson(fetchFn, c)) as { user_info?: { auth?: number | string; status?: string; exp_date?: string | null } };
  const info = data?.user_info;
  if (!info || Number(info.auth) !== 1) throw new Z8Error('auth_failed', 'Wrong username or password.');
  if (info.status && info.status.toLowerCase() === 'expired') throw new Z8Error('account_expired', 'This account has expired.');
  const exp = info.exp_date ? Number(info.exp_date) : undefined;
  return { expiresAt: exp && Number.isFinite(exp) ? exp : undefined };
}

export async function xtreamLiveCategories(fetchFn: FetchLike, c: XtreamCreds): Promise<XtreamCategory[]> {
  const data = await getJson(fetchFn, c, 'get_live_categories');
  return Array.isArray(data) ? (data as XtreamCategory[]) : [];
}

export async function xtreamLiveStreams(fetchFn: FetchLike, c: XtreamCreds): Promise<XtreamStream[]> {
  const data = await getJson(fetchFn, c, 'get_live_streams');
  return Array.isArray(data) ? (data as XtreamStream[]) : [];
}

export function xtreamLiveUrl(c: XtreamCreds, streamId: string, ext: 'ts' | 'm3u8' = 'ts'): string {
  const u = encodeURIComponent(c.username);
  const p = encodeURIComponent(c.password);
  return `${normalizeServerUrl(c.serverUrl)}/live/${u}/${p}/${streamId}.${ext}`;
}
