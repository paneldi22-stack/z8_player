import { describe, expect, it } from 'vitest';
import { parseM3u } from './m3u';
import { normalizeServerUrl, xtreamLogin, xtreamLiveStreams, xtreamLiveUrl } from './xtream';
import type { FetchLike } from './xtream';
import { redact } from './redact';
import { MemoryRepo, MemorySecretStore } from './repo';
import { resolveStreamUrl, syncPlaylist } from './sync';
import { Z8Error } from './types';

const reply = (body: unknown, status = 200): FetchLike => async () => ({
  ok: status >= 200 && status < 300, status, text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
});

describe('parseM3u', () => {
  const sample = [
    '#EXTM3U',
    '#EXTINF:-1 tvg-id="a.1" tvg-logo="http://x/l.png" group-title="News, World",Channel One, HD',
    'http://h/1.ts',
    '#EXTINF:-1 tvg-name="Two",',
    '#EXTGRP:Sport',
    'http://h/2.m3u8',
    '#EXTINF:-1,Three',
    'http://h/3.ts',
  ].join('\r\n');
  it('reads attributes, names with commas, and groups', () => {
    const e = parseM3u(sample);
    expect(e).toHaveLength(3);
    expect(e[0]).toMatchObject({ name: 'Channel One, HD', group: 'News, World', logo: 'http://x/l.png', tvgId: 'a.1', url: 'http://h/1.ts' });
    expect(e[1]).toMatchObject({ name: 'Two', group: 'Sport' });
    expect(e[2]!.group).toBeUndefined();
  });
  it('handles an empty or garbage file', () => {
    expect(parseM3u('')).toEqual([]);
    expect(parseM3u('<html>nope</html>')).toEqual([]);
  });
  it('parses 50 000 entries quickly', () => {
    const big = '#EXTM3U\n' + Array.from({ length: 50000 }, (_, i) => `#EXTINF:-1 group-title="G${i % 40}",C${i}\nhttp://h/${i}.ts`).join('\n');
    const t = Date.now();
    expect(parseM3u(big)).toHaveLength(50000);
    expect(Date.now() - t).toBeLessThan(1500);
  });
});

describe('xtream', () => {
  const creds = { serverUrl: 'host.example:8080/', username: 'u', password: 'p@ss' };
  it('normalizes server urls', () => {
    expect(normalizeServerUrl('host.example:8080/')).toBe('http://host.example:8080');
    expect(normalizeServerUrl('https://h.io/player_api.php')).toBe('https://h.io');
    expect(() => normalizeServerUrl('  ')).toThrow(Z8Error);
  });
  it('logs in, and rejects bad credentials and expired accounts', async () => {
    await expect(xtreamLogin(reply({ user_info: { auth: 1, status: 'Active', exp_date: '1900000000' } }), creds)).resolves.toEqual({ expiresAt: 1900000000 });
    await expect(xtreamLogin(reply({ user_info: { auth: 0 } }), creds)).rejects.toMatchObject({ code: 'auth_failed' });
    await expect(xtreamLogin(reply({}, 403), creds)).rejects.toMatchObject({ code: 'auth_failed' });
    await expect(xtreamLogin(reply({ user_info: { auth: 1, status: 'Expired' } }), creds)).rejects.toMatchObject({ code: 'account_expired' });
    await expect(xtreamLogin(reply('<html>'), creds)).rejects.toMatchObject({ code: 'bad_response' });
  });
  it('network errors never contain the password', async () => {
    const boom: FetchLike = async (u) => { throw new Error('ECONNREFUSED ' + u); };
    try { await xtreamLogin(boom, creds); throw new Error('should fail'); }
    catch (e) { expect((e as Z8Error).code).toBe('network'); expect((e as Error).message).not.toContain('p@ss'); }
  });
  it('builds an encoded stream url', () => {
    expect(xtreamLiveUrl(creds, '42')).toBe('http://host.example:8080/live/u/p%40ss/42.ts');
  });
  it('reads streams', async () => {
    expect(await xtreamLiveStreams(reply([{ stream_id: 1, name: 'A' }]), creds)).toHaveLength(1);
    expect(await xtreamLiveStreams(reply({ not: 'a list' }), creds)).toEqual([]);
  });
});

describe('redact', () => {
  it('hides credentials in query strings and stream paths', () => {
    expect(redact('http://h/get.php?username=bob&password=secret&type=m3u')).toBe('http://h/get.php?username=***&password=***&type=m3u');
    expect(redact('http://h/live/bob/secret/12.ts')).toBe('http://h/live/***/***/12.ts');
    expect(redact('failed for hunter2', ['hunter2'])).toBe('failed for ***');
  });
});

describe('sync and repo', () => {
  const xt = (): FetchLike => async (url) => {
    const a = new URL(url).searchParams.get('action');
    const body = a === 'get_live_categories' ? [{ category_id: '1', category_name: 'News' }, { category_id: '2', category_name: 'Sport' }]
      : a === 'get_live_streams' ? [{ stream_id: 10, name: 'N1', category_id: '1' }, { stream_id: 11, name: 'S1', category_id: '2' }, { stream_id: 12, name: 'S2', category_id: '2' }]
      : { user_info: { auth: 1, status: 'Active' } };
    return { ok: true, status: 200, text: async () => JSON.stringify(body) };
  };
  it('syncs an xtream playlist, keeps the password out of the repo, resolves a url', async () => {
    const repo = new MemoryRepo(); const secrets = new MemorySecretStore();
    const p = await repo.addPlaylist({ displayName: 'T', type: 'xtream', serverUrl: 'http://h', username: 'u', password: 'pw' }, secrets);
    expect(JSON.stringify(p)).not.toContain('pw');
    const steps: string[] = [];
    const r = await syncPlaylist(p, repo, secrets, xt(), (s) => steps.push(s.step));
    expect(r).toEqual({ categories: 2, channels: 3 });
    expect(steps).toEqual(['login', 'categories', 'channels', 'saving', 'done']);
    const cats = await repo.listCategories(p.id, 'live');
    expect((await repo.listChannels(p.id, cats[1]!.id)).map((c) => c.name)).toEqual(['S1', 'S2']);
    expect(await resolveStreamUrl(p, '10', secrets)).toBe('http://h/live/u/pw/10.ts');
  });
  it('keeps ids stable across a re-sync', async () => {
    const repo = new MemoryRepo(); const secrets = new MemorySecretStore();
    const p = await repo.addPlaylist({ displayName: 'T', type: 'xtream', serverUrl: 'http://h', username: 'u', password: 'pw' }, secrets);
    await syncPlaylist(p, repo, secrets, xt());
    const before = (await repo.listChannels(p.id, null)).map((c) => c.id);
    await syncPlaylist(p, repo, secrets, xt());
    expect((await repo.listChannels(p.id, null)).map((c) => c.id)).toEqual(before);
  });
  it('syncs an m3u playlist grouped by category and reports an empty one', async () => {
    const repo = new MemoryRepo(); const secrets = new MemorySecretStore();
    const p = await repo.addPlaylist({ displayName: 'M', type: 'm3u', m3uUrl: 'http://h/p.m3u' }, secrets);
    const text = '#EXTM3U\n#EXTINF:-1 group-title="A",One\nhttp://s/1\n#EXTINF:-1 group-title="B",Two\nhttp://s/2';
    expect(await syncPlaylist(p, repo, secrets, reply(text))).toEqual({ categories: 2, channels: 2 });
    await expect(syncPlaylist(p, repo, secrets, reply('#EXTM3U'))).rejects.toMatchObject({ code: 'empty' });
  });
  it('runs one sync at a time per playlist', async () => {
    const repo = new MemoryRepo(); const secrets = new MemorySecretStore();
    const p = await repo.addPlaylist({ displayName: 'M', type: 'm3u', m3uUrl: 'http://h/p.m3u' }, secrets);
    let calls = 0;
    const slow: FetchLike = async () => { calls++; await new Promise((r) => setTimeout(r, 20)); return { ok: true, status: 200, text: async () => '#EXTM3U\n#EXTINF:-1,A\nhttp://s/1' }; };
    const [a, b] = await Promise.all([syncPlaylist(p, repo, secrets, slow), syncPlaylist(p, repo, secrets, slow)]);
    expect(calls).toBe(1); expect(a).toEqual(b);
  });
  it('deleting a playlist removes its password', async () => {
    const repo = new MemoryRepo(); const secrets = new MemorySecretStore();
    const p = await repo.addPlaylist({ displayName: 'T', type: 'xtream', serverUrl: 'http://h', username: 'u', password: 'pw' }, secrets);
    await repo.deletePlaylist(p.id, secrets);
    expect(await secrets.get(p.secretRef!)).toBeUndefined();
    expect(await repo.listPlaylists()).toHaveLength(0);
  });
});
