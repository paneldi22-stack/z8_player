import React, { useEffect, useRef } from 'react';

export interface PlayerProps { url: string; onReady: () => void; onError: (message: string) => void }

/** Web player: plain video element, hls.js for .m3u8. MPEG-TS needs the native player (ExoPlayer) on a phone or TV. */
export function Player({ url, onReady, onError }: PlayerProps) {
  const ref = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    let hls: { destroy(): void } | null = null;
    let cancelled = false;
    const fail = () => !cancelled && onError("Couldn't play this one. Try another.");
    video.onplaying = () => !cancelled && onReady();
    video.onerror = fail;
    if (/\.m3u8(\?|$)/i.test(url) && !video.canPlayType('application/vnd.apple.mpegurl')) {
      import('hls.js').then(({ default: Hls }) => {
        if (cancelled) return;
        if (!Hls.isSupported()) return fail();
        const h = new Hls();
        h.on(Hls.Events.ERROR, (_e, d) => { if (d.fatal) fail(); });
        h.loadSource(url); h.attachMedia(video);
        hls = h;
        video.play().catch(() => {});
      }).catch(fail);
    } else {
      video.src = url;
      video.play().catch(() => {});
    }
    return () => { cancelled = true; hls?.destroy(); video.removeAttribute('src'); video.load(); };
  }, [url]);
  return React.createElement('video', {
    ref, controls: false, playsInline: true, muted: true, 'aria-label': 'Video',
    style: { width: '100%', height: '100%', backgroundColor: '#000', objectFit: 'contain' },
  });
}
