import React, { useEffect } from 'react';
import { useEvent } from 'expo';
import { useVideoPlayer, VideoView } from 'expo-video';

export interface PlayerProps { url: string; onReady: () => void; onError: (message: string) => void }

/** Phone and TV player: expo-video, which is ExoPlayer on Android and AVPlayer on iOS. */
export function Player({ url, onReady, onError }: PlayerProps) {
  const player = useVideoPlayer({ uri: url }, (p) => { p.play(); });
  const status = useEvent(player, 'statusChange', { status: player.status });
  useEffect(() => {
    if (status.status === 'readyToPlay') onReady();
    if (status.status === 'error') onError("Couldn't play this one. Try another.");
  }, [status.status]);
  return <VideoView player={player} style={{ width: '100%', height: '100%' }} contentFit="contain" nativeControls={false} />;
}
