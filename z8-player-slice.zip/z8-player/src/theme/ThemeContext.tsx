import React, { createContext, useContext } from 'react';
import { useColorScheme } from 'react-native';
import { darkColors, lightColors, type Colors } from './tokens';

export type ThemeSetting = 'system' | 'dark' | 'light';
const Ctx = createContext<{ colors: Colors; scheme: 'dark' | 'light' }>({ colors: darkColors, scheme: 'dark' });

export function ThemeProvider({ setting = 'system', children }: { setting?: ThemeSetting; children: React.ReactNode }) {
  const system = useColorScheme();
  const scheme: 'dark' | 'light' = setting === 'system' ? (system === 'light' ? 'light' : 'dark') : setting;
  const value = React.useMemo(() => ({ scheme, colors: scheme === 'dark' ? darkColors : lightColors }), [scheme]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useTheme = () => useContext(Ctx);
