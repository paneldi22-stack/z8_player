import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, Modal, Pressable, ScrollView, View, useWindowDimensions } from 'react-native';
import { useApp } from '../app/AppContext';
import { DEMO_URL, demoFetch } from '../app/demo';
import { Player } from '../player/Player';
import { redact } from '../logic/redact';
import { resolveStreamUrl, syncPlaylist } from '../logic/sync';
import { normalizeServerUrl } from '../logic/xtream';
import { Z8Error, type Category, type Channel, type Playlist, type SyncProgress } from '../logic/types';
import { useTheme } from '../theme/ThemeContext';
import { playerColors, radius, space } from '../theme/tokens';
import { Button, Card, Field, Header, ProgressBar, Skeleton, StateMessage, Text, useFocus } from '../ui/primitives';

export type Route =
  | { name: 'welcome' }
  | { name: 'playlists' }
  | { name: 'addMethod' }
  | { name: 'addXtream' }
  | { name: 'addM3u'; prefill?: string }
  | { name: 'sync'; playlistId: string }
  | { name: 'home'; playlistId: string }
  | { name: 'live'; playlistId: string }
  | { name: 'player'; playlistId: string; channelId: string; list: string[] }
  | { name: 'stub'; title: string };

export interface Nav { go(r: Route): void; back(): void; replace(r: Route): void }

const Page = ({ children }: { children: React.ReactNode }) => {
  const { colors } = useTheme();
  return <View style={{ flex: 1, backgroundColor: colors.bg }}>{children}</View>;
};
const Body = ({ children }: { children: React.ReactNode }) => (
  <ScrollView contentContainerStyle={{ padding: space[4], gap: space[4], width: '100%', maxWidth: 560, alignSelf: 'center' }} keyboardShouldPersistTaps="handled">{children}</ScrollView>
);

const messageOf = (e: unknown, secrets: string[] = []) =>
  e instanceof Z8Error ? e.message : redact("Something went wrong. Check the details and try again.", secrets);

// ---- S01 -------------------------------------------------------------------
export function Welcome({ nav }: { nav: Nav }) {
  return (
    <Page>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: space[6], gap: space[5] }}>
        <Text v="display" style={{ textAlign: 'center' }} accessibilityRole="header">Z8 Player</Text>
        <Text v="base" muted style={{ textAlign: 'center', maxWidth: 420 }}>
          Bring your own playlist and watch it here. Z8 Player doesn't include or sell any channels, movies or subscriptions.
        </Text>
        <Button title="Get started" size="lg" onPress={() => nav.replace({ name: 'playlists' })} />
      </View>
    </Page>
  );
}

// ---- S02 -------------------------------------------------------------------
export function Playlists({ nav }: { nav: Nav }) {
  const { repo, secrets } = useApp();
  const [items, setItems] = useState<Array<Playlist & { channels: number }> | null>(null);
  const [toDelete, setToDelete] = useState<Playlist | null>(null);
  const load = useCallback(async () => {
    const ps = await repo.listPlaylists();
    setItems(await Promise.all(ps.map(async (p) => ({ ...p, channels: (await repo.counts(p.id)).channels }))));
  }, [repo]);
  useEffect(() => { load(); }, [load]);

  return (
    <Page>
      <Header title="Playlists" right={items && items.length > 0 ? <Button title="Add playlist" variant="secondary" onPress={() => nav.go({ name: 'addMethod' })} /> : undefined} />
      {items === null ? (
        <View style={{ padding: space[4], gap: space[3] }}><Skeleton /><Skeleton /></View>
      ) : items.length === 0 ? (
        <StateMessage title="No playlists yet" body="Add one to start watching." action="Add playlist" onAction={() => nav.go({ name: 'addMethod' })} />
      ) : (
        <Body>
          {items.map((p) => (
            <Card key={p.id} style={{ gap: space[3] }}>
              <Pressable accessibilityRole="button" accessibilityLabel={`Open ${p.displayName}`} onPress={() => nav.go({ name: 'home', playlistId: p.id })} style={{ gap: space[1], minHeight: 44 }}>
                <Text v="lg" numberOfLines={1}>{p.displayName}</Text>
                <Text v="sm" muted>
                  {p.type === 'xtream' ? 'Provider sign-in' : 'Playlist link'} · {p.channels} channels{p.lastSyncAt ? ` · synced ${new Date(p.lastSyncAt * 1000).toLocaleDateString()}` : ''}
                </Text>
              </Pressable>
              <View style={{ flexDirection: 'row', gap: space[2] }}>
                <Button title="Refresh" variant="secondary" onPress={() => nav.go({ name: 'sync', playlistId: p.id })} />
                <Button title="Delete" variant="danger" onPress={() => setToDelete(p)} />
              </View>
            </Card>
          ))}
        </Body>
      )}
      <ConfirmDialog
        visible={!!toDelete} title="Delete this playlist?" body="This removes it from the app. Your provider's account isn't affected."
        confirm="Delete" onCancel={() => setToDelete(null)}
        onConfirm={async () => { if (toDelete) { await repo.deletePlaylist(toDelete.id, secrets); setToDelete(null); load(); } }}
      />
    </Page>
  );
}

function ConfirmDialog({ visible, title, body, confirm, onConfirm, onCancel }: { visible: boolean; title: string; body: string; confirm: string; onConfirm: () => void; onCancel: () => void }) {
  const { colors } = useTheme();
  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={onCancel}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', padding: space[4] }}>
        <View accessibilityViewIsModal style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: space[5], gap: space[3], width: '100%', maxWidth: 380, borderWidth: 1, borderColor: colors.border }}>
          <Text v="lg" accessibilityRole="header">{title}</Text>
          <Text v="sm" muted>{body}</Text>
          <View style={{ flexDirection: 'row', gap: space[2], justifyContent: 'flex-end' }}>
            <Button title="Cancel" variant="secondary" onPress={onCancel} />
            <Button title={confirm} variant="danger" onPress={onConfirm} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ---- S03 -------------------------------------------------------------------
export function AddMethod({ nav }: { nav: Nav }) {
  const { colors } = useTheme();
  const Option = ({ title, body, onPress }: { title: string; body: string; onPress: () => void }) => {
    const f = useFocus();
    return (
      <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={onPress} onFocus={f.onFocus} onBlur={f.onBlur}
        style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: space[4], gap: space[1], minHeight: 72, borderWidth: f.focused ? 3 : 1, borderColor: f.focused ? colors.accent : colors.border }}>
        <Text v="lg">{title}</Text><Text v="sm" muted>{body}</Text>
      </Pressable>
    );
  };
  return (
    <Page>
      <Header title="Add playlist" onBack={nav.back} />
      <Body>
        <Option title="Sign in with your provider" body="Server address, username and password." onPress={() => nav.go({ name: 'addXtream' })} />
        <Option title="Use a playlist link" body="Paste an M3U or M3U8 link." onPress={() => nav.go({ name: 'addM3u' })} />
        {__DEV__ ? <Option title="Try the demo playlist" body="Development only. Four fake channels, no network needed." onPress={() => nav.go({ name: 'addM3u', prefill: DEMO_URL })} /> : null}
      </Body>
    </Page>
  );
}

// ---- S04 -------------------------------------------------------------------
export function AddXtream({ nav }: { nav: Nav }) {
  const { repo, secrets } = useApp();
  const [f, setF] = useState({ name: '', server: '', user: '', pass: '' });
  const [errors, setErrors] = useState<Partial<Record<'server' | 'user' | 'pass', string>>>({});
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    const e: typeof errors = {};
    let server = '';
    try { server = normalizeServerUrl(f.server); } catch (x) { e.server = (x as Error).message; }
    if (!f.user.trim()) e.user = 'Enter your username.';
    if (!f.pass) e.pass = 'Enter your password.';
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    const p = await repo.addPlaylist({ displayName: f.name || 'My provider', type: 'xtream', serverUrl: server, username: f.user.trim(), password: f.pass }, secrets);
    nav.replace({ name: 'sync', playlistId: p.id });
  };
  return (
    <Page>
      <Header title="Sign in with your provider" onBack={nav.back} />
      <Body>
        <Field label="Name" value={f.name} onChangeText={(t) => setF({ ...f, name: t })} placeholder="My provider" />
        <Field label="Server address" value={f.server} onChangeText={(t) => setF({ ...f, server: t })} keyboard="url" placeholder="http://example.com:8080" error={errors.server} />
        <Field label="Username" value={f.user} onChangeText={(t) => setF({ ...f, user: t })} error={errors.user} />
        <Field label="Password" value={f.pass} onChangeText={(t) => setF({ ...f, pass: t })} secure error={errors.pass} />
        <Button title="Add playlist" size="lg" loading={busy} onPress={submit} />
      </Body>
    </Page>
  );
}

// ---- S05 -------------------------------------------------------------------
export function AddM3u({ nav, prefill }: { nav: Nav; prefill?: string }) {
  const { repo, secrets } = useApp();
  const [name, setName] = useState(prefill ? 'Demo' : '');
  const [url, setUrl] = useState(prefill ?? '');
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    const u = url.trim();
    if (!/^https?:\/\/\S+$/i.test(u)) { setError("That link doesn't look right. It should start with http:// or https://"); return; }
    setError(undefined); setBusy(true);
    const p = await repo.addPlaylist({ displayName: name || 'My playlist', type: 'm3u', m3uUrl: u }, secrets);
    nav.replace({ name: 'sync', playlistId: p.id });
  };
  return (
    <Page>
      <Header title="Use a playlist link" onBack={nav.back} />
      <Body>
        <Field label="Name" value={name} onChangeText={setName} placeholder="My playlist" />
        <Field label="Playlist link" value={url} onChangeText={setUrl} keyboard="url" placeholder="https://example.com/list.m3u" error={error} />
        <Button title="Add playlist" size="lg" loading={busy} onPress={submit} />
      </Body>
    </Page>
  );
}

// ---- S06 -------------------------------------------------------------------
const STEP_TEXT: Record<SyncProgress['step'], string> = {
  login: 'Signing in...', categories: 'Loading categories...', channels: 'Loading channels...', saving: 'Saving your channels...', done: 'Done.',
};
export function Sync({ nav, playlistId }: { nav: Nav; playlistId: string }) {
  const { repo, secrets, fetchFn } = useApp();
  const [progress, setProgress] = useState<SyncProgress>({ step: 'login', fraction: 0.05 });
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [isNew, setIsNew] = useState(false);
  useEffect(() => {
    let live = true;
    (async () => {
      const p = await repo.getPlaylist(playlistId);
      if (!p) return nav.replace({ name: 'playlists' });
      setIsNew(!p.lastSyncAt); setError(null); setProgress({ step: 'login', fraction: 0.05 });
      try {
        const f = p.m3uUrl === DEMO_URL ? demoFetch : fetchFn;
        await syncPlaylist(p, repo, secrets, f, (s) => live && setProgress(s));
        if (live) nav.replace({ name: 'playlists' });
      } catch (e) {
        if (live) setError(messageOf(e));
      }
    })();
    return () => { live = false; };
  }, [attempt]);

  const leave = async () => {
    // A playlist that never loaded is removed so a typo doesn't leave a broken card behind.
    if (isNew) await repo.deletePlaylist(playlistId, secrets);
    nav.back();
  };
  return (
    <Page>
      <Header title="Loading playlist" />
      {error ? (
        <View style={{ gap: space[3] }}>
          <StateMessage tone="error" title="Couldn't load this playlist" body={`${error} Check the details and try again.`} action="Try again" onAction={() => setAttempt(attempt + 1)} />
          <View style={{ alignItems: 'center' }}><Button title="Go back" variant="secondary" onPress={leave} /></View>
        </View>
      ) : (
        <Body>
          <Text v="base" accessibilityRole="text">Playlist added. Loading your channels...</Text>
          <ProgressBar fraction={progress.fraction} />
          <Text v="sm" muted>{STEP_TEXT[progress.step]}</Text>
        </Body>
      )}
    </Page>
  );
}

// ---- S07 -------------------------------------------------------------------
export function Home({ nav, playlistId }: { nav: Nav; playlistId: string }) {
  const { repo } = useApp();
  const { colors } = useTheme();
  const [p, setP] = useState<Playlist>();
  const [n, setN] = useState<number>();
  useEffect(() => { (async () => { setP(await repo.getPlaylist(playlistId)); setN((await repo.counts(playlistId)).channels); })(); }, [playlistId]);
  const Tile = ({ title, sub, onPress, wide }: { title: string; sub: string; onPress: () => void; wide?: boolean }) => {
    const f = useFocus();
    return (
      <Pressable accessibilityRole="button" accessibilityLabel={`${title}, ${sub}`} onPress={onPress} onFocus={f.onFocus} onBlur={f.onBlur}
        style={{ flexGrow: 1, flexBasis: wide ? '100%' : '45%', minHeight: wide ? 120 : 96, backgroundColor: colors.surface, borderRadius: radius.lg, padding: space[4], justifyContent: 'space-between', borderWidth: f.focused ? 3 : 1, borderColor: f.focused ? colors.accent : colors.border }}>
        <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: colors.accent }} />
        <View><Text v="lg">{title}</Text><Text v="sm" muted>{sub}</Text></View>
      </Pressable>
    );
  };
  const soon = (title: string) => () => nav.go({ name: 'stub', title });
  return (
    <Page>
      <Header title={p?.displayName ?? ' '} onBack={nav.back} right={<Button title="Settings" variant="ghost" onPress={soon('Settings')} />} />
      <Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space[3] }}>
          <Tile wide title="Live TV" sub={n === undefined ? ' ' : `${n} channels`} onPress={() => nav.go({ name: 'live', playlistId })} />
          <Tile title="Movies" sub="Coming soon" onPress={soon('Movies')} />
          <Tile title="Series" sub="Coming soon" onPress={soon('Series')} />
          <Tile title="Favorites" sub="Coming soon" onPress={soon('Favorites')} />
          <Tile title="Search" sub="Coming soon" onPress={soon('Search')} />
        </View>
      </Body>
    </Page>
  );
}

// ---- S08 -------------------------------------------------------------------
export function LiveTv({ nav, playlistId }: { nav: Nav; playlistId: string }) {
  const { repo } = useApp();
  const { colors } = useTheme();
  const { width } = useWindowDimensions();
  const [cats, setCats] = useState<Category[] | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [chans, setChans] = useState<Channel[] | null>(null);
  useEffect(() => { (async () => setCats(await repo.listCategories(playlistId, 'live')))(); }, [playlistId]);
  useEffect(() => { setChans(null); (async () => setChans(await repo.listChannels(playlistId, sel)))(); }, [playlistId, sel]);

  const Chip = ({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) => {
    const f = useFocus();
    return (
      <Pressable accessibilityRole="button" accessibilityState={{ selected: active }} accessibilityLabel={label} onPress={onPress} onFocus={f.onFocus} onBlur={f.onBlur}
        style={{ minHeight: 44, paddingHorizontal: space[4], justifyContent: 'center', borderRadius: radius.pill, backgroundColor: active ? colors.accent : colors.surface, borderWidth: f.focused ? 3 : 1, borderColor: f.focused ? colors.accent : colors.border }}>
        <Text v="sm" color={active ? colors.onAccent : colors.text} style={{ fontWeight: '600' }}>{label}</Text>
      </Pressable>
    );
  };
  const Row = ({ c, list }: { c: Channel; list: string[] }) => {
    const f = useFocus();
    return (
      <Pressable accessibilityRole="button" accessibilityLabel={c.name} onPress={() => nav.go({ name: 'player', playlistId, channelId: c.id, list })} onFocus={f.onFocus} onBlur={f.onBlur}
        style={{ minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: space[3], paddingHorizontal: space[3], borderRadius: radius.md, borderWidth: f.focused ? 3 : 0, borderColor: colors.accent }}>
        <View style={{ width: 40, height: 40, borderRadius: radius.sm, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' }}>
          <Text v="sm" color={colors.accent} style={{ fontWeight: '700' }}>{c.name.trim().slice(0, 2).toUpperCase()}</Text>
        </View>
        <Text v="base" style={{ flex: 1, fontWeight: '600' }} numberOfLines={1}>{c.name}</Text>
      </Pressable>
    );
  };
  const list = (chans ?? []).map((c) => c.id);
  return (
    <Page>
      <Header title="Live TV" onBack={nav.back} />
      {cats === null ? (
        <View style={{ padding: space[4], gap: space[3] }}><Skeleton /><Skeleton /><Skeleton /></View>
      ) : (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ gap: space[2], paddingHorizontal: space[4], paddingBottom: space[3] }}>
            <Chip label="All" active={sel === null} onPress={() => setSel(null)} />
            {cats.map((c) => <Chip key={c.id} label={c.name} active={sel === c.id} onPress={() => setSel(c.id)} />)}
          </ScrollView>
          {chans === null ? (
            <View style={{ padding: space[4], gap: space[3] }}><Skeleton /><Skeleton /><Skeleton /></View>
          ) : chans.length === 0 ? (
            <StateMessage title="Nothing here yet" body="This category has no channels." />
          ) : (
            <FlatList data={chans} keyExtractor={(c) => c.id} renderItem={({ item }) => <Row c={item} list={list} />}
              contentContainerStyle={{ paddingHorizontal: space[2], width: '100%', maxWidth: width > 720 ? 720 : undefined, alignSelf: 'center' }} initialNumToRender={20} windowSize={9} />
          )}
        </>
      )}
    </Page>
  );
}

// ---- S09 -------------------------------------------------------------------
export function LivePlayer({ nav, playlistId, channelId, list }: { nav: Nav; playlistId: string; channelId: string; list: string[] }) {
  const { repo, secrets } = useApp();
  const c = playerColors;
  const [index, setIndex] = useState(Math.max(0, list.indexOf(channelId)));
  const [channel, setChannel] = useState<Channel>();
  const [url, setUrl] = useState<string>();
  const [state, setState] = useState<'loading' | 'playing' | 'error'>('loading');
  const [attempt, setAttempt] = useState(0);
  const [overlay, setOverlay] = useState(true);
  const hide = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bump = () => { setOverlay(true); if (hide.current) clearTimeout(hide.current); hide.current = setTimeout(() => setOverlay(false), 4000); };

  useEffect(() => {
    let live = true;
    setState('loading'); setUrl(undefined);
    (async () => {
      const p = await repo.getPlaylist(playlistId);
      const all = await repo.listChannels(playlistId, null);
      const ch = all.find((x) => x.id === list[index]);
      if (!p || !ch) return live && setState('error');
      try {
        const u = await resolveStreamUrl(p, ch.streamRef, secrets);
        if (live) { setChannel(ch); setUrl(u); }
      } catch { if (live) setState('error'); }
    })();
    return () => { live = false; };
  }, [index, attempt]);
  useEffect(() => { bump(); return () => { if (hide.current) clearTimeout(hide.current); }; }, [index]);

  const zap = (d: number) => setIndex((i) => (i + d + list.length) % list.length);
  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      {url && state !== 'error' ? <Player key={`${index}-${attempt}`} url={url} onReady={() => setState('playing')} onError={() => setState('error')} /> : null}
      <Pressable accessibilityLabel="Show controls" style={{ position: 'absolute', inset: 0 as any }} onPress={() => (overlay ? setOverlay(false) : bump())} />
      {state === 'loading' ? <View pointerEvents="none" style={{ position: 'absolute', inset: 0 as any, alignItems: 'center', justifyContent: 'center' }}><Text v="base" color={c.textMuted} accessibilityRole="text">Loading...</Text></View> : null}
      {state === 'error' ? (
        <View style={{ position: 'absolute', inset: 0 as any, alignItems: 'center', justifyContent: 'center', gap: space[3], padding: space[5] }}>
          <Text v="lg" color={c.text} style={{ textAlign: 'center' }} accessibilityRole="header">Couldn't play this one. Try another.</Text>
          <View style={{ flexDirection: 'row', gap: space[2] }}>
            <Button title="Retry" onPress={() => setAttempt(attempt + 1)} />
            <Button title="Next channel" variant="secondary" onPress={() => zap(1)} />
            <Button title="Back" variant="ghost" onPress={nav.back} />
          </View>
        </View>
      ) : null}
      {overlay && state !== 'error' ? (
        <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: space[4], gap: space[3], backgroundColor: 'rgba(0,0,0,0.6)' }}>
          <Text v="lg" color={c.text} numberOfLines={1}>{channel?.name ?? ' '}</Text>
          <View style={{ flexDirection: 'row', gap: space[2] }}>
            <Button title="Back" variant="secondary" onPress={nav.back} />
            <Button title="Previous" variant="secondary" onPress={() => zap(-1)} accessibilityLabel="Previous channel" />
            <Button title="Next" variant="secondary" onPress={() => zap(1)} accessibilityLabel="Next channel" />
          </View>
        </View>
      ) : null}
    </View>
  );
}

// ---- Not built yet -----------------------------------------------------------
export function Stub({ nav, title }: { nav: Nav; title: string }) {
  return (
    <Page>
      <Header title={title} onBack={nav.back} />
      <StateMessage title="Coming soon" body="This part of Z8 Player isn't built yet." action="Go back" onAction={nav.back} />
    </Page>
  );
}
